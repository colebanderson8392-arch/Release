import '../class-components.spec'
